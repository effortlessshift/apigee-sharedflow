try {
  var startTimeStamp = context.getVariable("log.startTimeStamp");
  var apiName = context.getVariable("operation");
  var proxyRevision = context.getVariable("log.proxyRevision");
  var apigeeProxyName = context.getVariable("log.proxyName");
  var proxyEndpointName = context.getVariable("log.proxyEndpointName");
  var proxyVerb = context.getVariable("log.proxyVerb");
  var proxyScheme = context.getVariable("log.proxyScheme");
  var proxyHost = "apigee-acme";
  var proxyURI = context.getVariable("log.proxyURI");
  var proxyRequest = context.getVariable("private.log.proxyRequest");
  var proxyStartTimeStamp = context.getVariable("log.proxyStartTimeStamp");
  var proxyEndTimeStamp = context.getVariable("log.proxyEndTimeStamp");
  var clientIP = context.getVariable("log.clientIP");
  var clientPort = context.getVariable("log.clientPort");
  var logTargetRequestVerb = context.getVariable("log.targetVerb");
  var targetURI = context.getVariable("log.targetURI");
  var requestURI = context.getVariable("log.requestURI");
  var targetRequest = context.getVariable("log.targetRequest");
  var routeName = context.getVariable("log.routeName");
  var routeTargetName = context.getVariable("log.routeTargetName");
  var targetName = context.getVariable("log.TargetName");
  var targetReqStartTimeStamp = context.getVariable(
    "log.targetReqStartTimeStamp"
  );
  var targetReqEndTimeStamp = context.getVariable("log.targetReqEndTimeStamp");
  var targetResponse = context.getVariable("log.targetResponse");
  var targetResponsePhrase = context.getVariable("log.targetResponsePhrase");
  var targetResStartTimeStamp = context.getVariable(
    "log.targetResStartTimeStamp"
  );
  var targetResEndTimeStamp = context.getVariable("log.targetResEndTimeStamp");
  var clientHost = context.getVariable("log.clientHost");
  var targetResponseCode = context.getVariable("log.targetResponseCode");
  var proxyResponseStatusCode = context.getVariable("response.status.code");
  var proxyResponseReasonPhrase = context.getVariable("response.reason.phrase");
  var targetHeaderNames = context.getVariable("log.targetHeaderNames");
  var targetResponseHeaderNames = context.getVariable(
    "log.targetResponseHeaderNames"
  );
  var contentType = context.getVariable("log.Content-Type");
  var accept = context.getVariable("log.Accept");
  var environmentName = context.getVariable("log.environmentName");
  var organizationName = context.getVariable("log.organizationName");
  var isError = context.getVariable("log.isError");
  var targetScheme = context.getVariable("log.targetScheme");
  var targetHost = context.getVariable("log.targetHost");
  var targetPort = context.getVariable("log.targetPort");
  var errorStatusCode = context.getVariable("flow.api.error.status");
  var errorReasonPhrase = context.getVariable("flow.api.error.reason");
  var isErrorLog = context.getVariable("isErrorLog");
  var isTargetExecuted = context.getVariable("log.isTargetExecuted");
  var logEverything = context.getVariable("metadata.log.everything");
  var reqContentLength = context.getVariable("request.header.Content-Length");
  var resContentLength = context.getVariable("response.header.Content-Length");
  var requestHeaderCount = context.getVariable("proxyHeaderCount");
  var targetRequestHeaderCount = context.getVariable("targetHeaderCount");
  var responseHeaderCount = context.getVariable("response.headers.count");
  var messageCorrId = context.getVariable("messageCorrId");
  var logRequestHeaders = context.getVariable("logRequestHeaders");
  var reqHeaders = context.getVariable("reqHeaders");

  var cacheHit = "false";

  /** Handle Proxy Response Headers for logging **/
  var reqProxyheaderFieldsCollection =
    context.getVariable("request.headers.names") + "";
  reqProxyheaderFieldsCollection = reqProxyheaderFieldsCollection.substr(
    1,
    reqProxyheaderFieldsCollection.length - 2
  );
  var reqProxyheadersArray = reqProxyheaderFieldsCollection.split(", ");
  if (reqProxyheadersArray.length > 0) {
    var logProxyRequestHeaders = "{";
    for (var i = 0; i < reqProxyheadersArray.length; i++) {
      if (reqProxyheadersArray[i].toLowerCase() !== "authorization") {
        if (i !== 0) logProxyRequestHeaders = logProxyRequestHeaders + ",";
        logProxyRequestHeaders =
          logProxyRequestHeaders +
          '"' +
          reqProxyheadersArray[i] +
          '":"' +
          context.getVariable("request.header." + reqProxyheadersArray[i]) +
          '"';
      }
    }
    logProxyRequestHeaders =
      logProxyRequestHeaders +
      ', "request-timestamp" : "' +
      context.getVariable("log.startTimeStamp") +
      '"';
    logProxyRequestHeaders =
      logProxyRequestHeaders +
      ', "response-timestamp" : "' +
      context.getVariable("log.targetResEndTimeStamp") +
      '"';
    logProxyRequestHeaders =
      logProxyRequestHeaders + ', "gateway-type" : "APIGEE"';

    logProxyRequestHeaders = logProxyRequestHeaders + "}";
    context.setVariable("logProxyRequestStr", logProxyRequestHeaders);
    var reqHeaders = JSON.parse(logProxyRequestHeaders);
    context.setVariable("logProxyResponseHeaders", reqHeaders);
  }

  var queryParams = context.getVariable("request.queryparams.names") + "";
  context.setVariable("queryParams", queryParams);
  queryParams = queryParams.substr(1, queryParams.length - 2);

  var queryParamsArray = queryParams.split(", ");
  context.setVariable("queryParamsArray", queryParamsArray.length);
  if (queryParamsArray.length > 0) {
    var logRequestQueryParams = "{";
    for (var i = 0; i < queryParamsArray.length; i++) {
      if (
        context.getVariable("request.queryparam." + queryParamsArray[i]) !==
        null
      ) {
        if (i !== 0) logRequestQueryParams = logRequestQueryParams + ",";
        logRequestQueryParams =
          logRequestQueryParams +
          '"' +
          queryParamsArray[i] +
          '":"' +
          context.getVariable("request.queryparam." + queryParamsArray[i]) +
          '"';
      }
    }
    logRequestQueryParams = logRequestQueryParams + "}";

    context.setVariable("logRequestQueryParams", logRequestQueryParams);
    var queryParmObj = JSON.parse(logRequestQueryParams);
  }

  context.setVariable("logProxyRequestURI", req_url);
  var logProxyRequestURI = req_url;
  var req_verb = context.getVariable("log.proxyVerb");
  var req_scheme = context.getVariable("log.proxyScheme");
  var req_host = context.getVariable("log.proxyHost");
  var req_request_uri = context.getVariable("log.proxyURI");
  req_request_uri = getPathFromUrl(req_request_uri);

  // 	context.setVariable("target.copy.pathsuffix", false);
  var req_url = req_scheme + "://" + req_host + req_request_uri;
  context.setVariable("logProxyRequestURI", req_url);
  var logProxyRequestURI = req_request_uri;

  /** Handle Proxy Request Verb Parameter for logging **/
  context.setVariable("logProxyRequestVerb", req_verb);
  var logProxyRequestVerb = req_verb;

  /** Handle Proxy Request Payload Parameter for logging **/
  var proxyRequest = context.getVariable("private.log.proxyRequest");
  if (proxyRequest !== null || proxyRequest === "") {
    var logProxyRequestPayload = proxyRequest.replace(/"/g, '"');
    context.setVariable(
      "private.logProxyRequestPayload",
      logProxyRequestPayload
    );
  }
	
	var logmessage = [];
	logmessage.push({
    complianceCheckDTO: {
      request: {
        headerParams: reqHeaders,
        queryParams: queryParmObj != null ? queryParmObj : null,
        verb: proxyVerb,
        path: logProxyRequestURI,
        requestBody: logProxyRequestPayload,
        hostname: "apigee-acme",
      },
      response: {},
      clientIp: context.getVariable("log.clientIP"),
      clientHost: context.getVariable("log.clientHost"),
      serverHost: context.getVariable("log.targetHost"),
      serverIp: "54.148.165.148",
    },
  });

  // Call logger proxy
  var messageCompliance = context.setVariable(
    "logMessageCompliance",
    JSON.stringify(logmessage[0])
  );
  var workspaceId = context.getVariable("complianceWorkspace");
  var complianceKey = context.getVariable("complianceApikey");
  var complianceClient = context.getVariable("complianceClient");
  var complianceWorkspaceId = context.getVariable("complianceWorkspaceId");

  var headers = {
    "Content-Type": "application/json",
    "tenant": complianceWorkspaceId,
  };
  var endpoint = context.getVariable("securityURL");
  context.setVariable("endpoint", endpoint);
  context.setVariable("logmessage", JSON.stringify(logmessage[0]));
  var logRequest = new Request(
    endpoint,
    "POST",
    headers,
    JSON.stringify(logmessage[0])
  );
  context.setVariable("securityRequestToHost", JSON.stringify(logRequest));
  var exchange = httpClient.send(logRequest);
  exchange.waitForComplete();
  var response = exchange.getResponse();
  var securityRes = response.content;
  context.setVariable("responseStr",securityRes);
  var blockRequestsOnSecurityThreats = context.getVariable("blockRequestsOnSecurityThreats");
  if(blockRequestsOnSecurityThreats && securityRes != null && securityRes.policyViolations){
      context.setVariable("block",true);
  }
} catch (error) {
  context.setVariable("errorPosting", JSON.stringify(error));
}

function getPathFromUrl(url) {
  return url.split(/[?#]/)[0];
}